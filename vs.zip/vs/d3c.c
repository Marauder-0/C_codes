// C program to implement max between 2 number using ternary operator
#include<stdio.h>
int main(void)
{
int a,b;
printf("Enter Values for a and b\n");
scanf("%d%d",&a,&b);
a>b? printf("A is max\n"):printf("B is max\n");
return 0;
}

