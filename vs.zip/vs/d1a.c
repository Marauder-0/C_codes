// c program to to display personal information
#include<stdio.h>
int main(void)
{
printf("Personal Information\n");
printf("Name: Dhananjay Sharma\n");
printf("Section: L\n");
printf("Age: 19\n");
printf("Roll Number: 63\n");
printf("Phone No.: 7398497550\n");
return 0;
}

