/* C program for this pattern 9

*****
 ****
  ***
   **
    *
   **
  ***
 ****
*****  
                  */
#include<stdio.h>
int main()
{
int i,j,k;
for(
