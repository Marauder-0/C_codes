// C program to implement addition of two numbers
#include<stdio.h>
int main(void)
{
int i,j;
printf("Enter Two Values for addditon\n");
scanf("%d%d", &i,&j);
printf("Sum is %d\n", i+j);
return 0;
}

